l1 = 0.4;
l2 = 0.3;
l3 = 0.5;
l4 = 0.3;

L1 = Revolute();
L1.a = 0;
L1.d = l1;
L1.alpha= -pi/2; 

L2 = Revolute();
L2.a = 0.0;
L2.d = l2;
L2.alpha= pi/2;

L3 = Revolute();
L3.a = 0.0;
L3.d = 0.35;
L3.alpha= -pi/2; 

L4 = Revolute();
L4.a = 0.35;
L4.d = 0.0;
L4.alpha= pi/2; 

% Add two joints for manipulator; 

robot = SerialLink([L1 L2 L3 L4] )
robot.name = "Robot arm semester project";
RPR_robot.tool = SE3.Rz(pi/2) * SE3.Ry(-pi/2)
robot.teach()

%%

l1 = 0.4;
l2 = 0.3;
l3 = 0.5;
l4 = 0.3;


L1 = Revolute();
L1.a = 0; 
L1.d = l1;
L1.alpha = -pi/2; 

L2 = Revolute();
L2.a = 0;
L2.d = L2; 
L2.alpha = pi/2; 

L3 = Revolute();
L3.a = 0;
L3.d = L3;
L3.alpha = -pi/2; 

L4 = Revolute(); 
L4.alpha = pi; 
L4.a = 0;
L4.a = -l4; 

robot = SerialLink([L1,L2,L3,L4]);

robot.teach()

%%
% Forward kinematics using toolbox. The arythmetics of matlab is not
% entirely presice, Therefore looks messy. 
robot.fkine([q1,q2,q3,q4,q5,q6])

%%
%Ready posisiton
q1 = [0,0,0,-pi/2,0,0]; %Joint angles
T1 = robot.fkine(q1); 
T2 = SE3(0.45, -0.4, -0.25);
T2r = SE3.Ry(pi/2);


T2 = T2 *T2r;

q2 = robot.ikine(T2);


figure(1)
folder = "C:\UIB"
filename = 'robot_movement.gif';
trplot(T2,'color','g','frame','T2')




%%
%Exporting robot movement to gif:
for n = 1:50
    robot.plot(qj(n,:))
    drawnow
    frame = getframe(1);
    im = frame2im(frame);
    [imind,cm] = rgb2ind(im,256);
    if n == 1
          imwrite(imind,cm,fullfile(folder,filename),'gif', 'Loopcount',inf);
    else
          imwrite(imind,cm,fullfile(folder,filename),'gif','WriteMode','append');
    end
end

%%
%Feil, får se på senere





e = sqrt(10^(0.25/10)-1)

n = acosh(10^(2)/e)/acosh(2)

omega = cosh(acosh(sqrt(10^0.3-1)/e)/6)
f = omega*800


